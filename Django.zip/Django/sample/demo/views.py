from django.shortcuts import render

from django.http import HttpResponse

# Create your views here.
def hi(response):
	return HttpResponse("Hi ALL")

def hello(response):
	return HttpResponse("Hi hello")

def clg(response):
	return HttpResponse("PSCMR COLLAGE OF ENGINEERING AND TECHNOLOGY")	

def branch(response):
	return HttpResponse("CSE 3rd Year")	

def welcome(response):
	return HttpResponse("Welcome to Django Workshop")

def data(response):
    html = "<html><body><h1>WELCOME TO DJANGO WORKSHOP</h1></body></html>" 
    return HttpResponse(html)

def hey(response,name):
	return HttpResponse(" this is your name: {}".format(name))

def rollno(response,id):
	return HttpResponse("Roll Num : {}".format(id))

def age(response,a,b):
	return HttpResponse("Roll Num : {} and {}".format(a,b))

def emp(response,name,age,salary,year):
	return HttpResponse("NAME : {} AGE :{} SALARY:{} YEAR:{}".format(name,age,salary,year))
